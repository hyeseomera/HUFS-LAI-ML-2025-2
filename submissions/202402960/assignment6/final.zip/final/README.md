# 스페인어 동사 형태 분석기 (Spanish Verb Analyzer)
## 프로젝트 소개
- 이 도구는 스페인어 동사의 변형된 형태를 입력받아 세 가지 문법 정보를 자동으로 판별합니다.
  - Mood
  - Tense
  - Person
## 실행 방법
1) 패키지 설치
   - pip install -r requirements.txt
2) 모델 실행
   - python3 service.py
3) 동사 입력
## 모델 가중치 다운로드
- 프로젝트 폴더 내의 `model/` 디렉토리에 파일이 없다면 아래의 링크를 통해 다운로드 받아주세요.
- 링크 : (https://drive.google.com/drive/folders/14dNRaq8jChEXL-dlD9mS-vvfUAnq6zsF?usp=drive_link) - (best_model.pt)