import torch
import torch.nn as nn
import pandas as pd
import os
from sklearn.preprocessing import LabelEncoder

#모델 정의

class CharLSTMMultiHead(nn.Module):
    def __init__(self, vocab_size, embed_dim,
                 hidden_dim, num_layers,
                 num_moods, num_tenses, num_persons,
                 dropout=0.5):
        super().__init__()

        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        self.lstm = nn.LSTM(
            embed_dim,
            hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout if num_layers > 1 else 0.0,
        )

        lstm_out_dim = hidden_dim * 2

        self.mood_head = nn.Sequential(
            nn.Linear(lstm_out_dim, 128),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(128, num_moods),
        )
        self.tense_head = nn.Sequential(
            nn.Linear(lstm_out_dim, 128),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(128, num_tenses),
        )
        self.person_head = nn.Sequential(
            nn.Linear(lstm_out_dim, 128),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(128, num_persons),
        )

    def forward(self, x):
        emb = self.embedding(x)
        out, (h_n, _) = self.lstm(emb)
        h_forward = h_n[-2]
        h_backward = h_n[-1]
        h = torch.cat([h_forward, h_backward], dim=1)
        return self.mood_head(h), self.tense_head(h), self.person_head(h)


#전처리 및 모델 로드

class VerbClassifierService:
    def __init__(self, model_path="model/best_model.pt"):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        # 문자 사전
        all_chars = list("abcdefghijklmnopqrstuvwxyzáéíóúüñ")
        self.char_to_id = {"<PAD>": 0, "<UNK>": 1}
        for i, ch in enumerate(sorted(all_chars), start=2):
            self.char_to_id[ch] = i
        self.vocab_size = 34
        self.max_len = 20

        # LabelEncoder 재구축
        self.mood_le = LabelEncoder()
        self.tense_le = LabelEncoder()
        self.person_le = LabelEncoder()

        # 고정 라벨
        self.mood_le.fit(["indicative", "subjunctive", "imperative"])
        self.tense_le.fit(["conditional", "conditional_perfect", "future", "future_perfect", "imperfect", "pluperfect", "present", "present_perfect", "preterite", "preterite_anterior"])
        self.person_le.fit(["1sg", "2sg", "3sg", "1pl", "2pl", "3pl"])

        # 모델 초기화
        self.model = CharLSTMMultiHead(
            vocab_size=self.vocab_size,
            embed_dim=64,
            hidden_dim=256,
            num_layers=3,
            num_moods=len(self.mood_le.classes_),
            num_tenses=len(self.tense_le.classes_),
            num_persons=len(self.person_le.classes_),
            dropout=0.5,
        ).to(self.device)

        # 모델 로드
        if not os.path.exists(model_path):
            raise FileNotFoundError(
                f"Model not found at {model_path}. Please place best_model.pt inside model/ directory."
            )
        self.model.load_state_dict(torch.load(model_path, map_location=self.device))
        self.model.eval()

    #단일 단어 예측
    def predict(self, verb):
        verb = verb.lower()
        ids = [self.char_to_id.get(ch, 1) for ch in verb]

        if len(ids) < self.max_len:
            ids += [0] * (self.max_len - len(ids))
        else:
            ids = ids[:self.max_len]

        x = torch.tensor([ids], dtype=torch.long).to(self.device)

        with torch.no_grad():
            out_mood, out_tense, out_person = self.model(x)

        mood_pred = self.mood_le.inverse_transform([out_mood.argmax(1).item()])[0]
        tense_pred = self.tense_le.inverse_transform([out_tense.argmax(1).item()])[0]
        person_pred = self.person_le.inverse_transform([out_person.argmax(1).item()])[0]

        return {
            "verb": verb,
            "mood": str(mood_pred),
            "tense": str(tense_pred),
            "person": str(person_pred)
        }


#CLI 실행 예시
if __name__ == "__main__":
    service = VerbClassifierService()
    print("Spanish Verb Classifier Ready!")

    while True:
        verb = input("\nEnter a Spanish verb form (or 'quit'): ")

        if verb == "quit":
            break

        result = service.predict(verb)
        print(result)
